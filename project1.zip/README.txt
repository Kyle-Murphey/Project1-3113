Project 1

author: Kyle Murphey

Resources:
    https://stackoverflow.com/questions/20051619/store-an-integer-in-a-char-array
    https://stackoverflow.com/questions/29547115/how-to-convert-string-to-hex-value-in-c/29547549
    https://stackoverflow.com/questions/16644906/how-to-check-if-a-string-is-a-number
    Linux programmer's manual
    Project specification page